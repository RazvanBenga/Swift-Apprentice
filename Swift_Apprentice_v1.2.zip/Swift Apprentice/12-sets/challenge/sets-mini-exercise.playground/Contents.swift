// -------------------
// | Mini Challanges |
// -------------------

// Write a function that removes all duplicates from an array of integers.

var numbers = [1, 2, 3, 1, 1, 4, 2]
numbers = Array(Set(numbers))


// Quick question: which set operation would you use to find a good time to meet?

// You would use intersect, since it returns all the times slots everyone agrees upon
