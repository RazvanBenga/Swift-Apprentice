import Foundation

let myFavoriteSong: String? = "The Final Countdown"
//let myFavoriteSong: String? = nil

if let song = myFavoriteSong {
  print(song)
} else {
  print("I don’t have a favorite song.")
}


