import Foundation

// Challenge A

//let character: Character = "Dog" // INVALID
//let character: Character = "🐶" // VALID
//let string: String = "Dog" // VALID
//let string: String = "🐶" // VALID

//let name = "Matt"
//name += " Galloway"
// 'name' is a constant, so you can't assign to it again on the second line.

// Challenge B

let value = 10
let multiplier = 5
let sum = "\(value) multiplied by \(multiplier) equals \(value * multiplier)"
// sum = "10 multiplied by 5 equals 50"
